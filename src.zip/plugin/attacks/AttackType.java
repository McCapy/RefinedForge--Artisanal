package plugin.attacks;

public enum AttackType {
    SLASH,THRUST,BLANK,MAGICSHOT
}
